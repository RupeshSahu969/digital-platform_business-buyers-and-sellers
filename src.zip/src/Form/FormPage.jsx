import React, { useState, useEffect } from 'react';
import FormField from './FormField';
import { useFormBuilder } from '../AuthContext/AuthContext';

export default function FormPage() {
  const { state, validateForm, submitForm } = useFormBuilder();
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [formSubmissions, setFormSubmissions] = useState([]);

  useEffect(() => {
    const submissions = JSON.parse(localStorage.getItem('formSubmissions') || '[]');
    setFormSubmissions(submissions);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      submitForm();

      // Update local state from localStorage after submitForm presumably updates it
      const updatedSubmissions = JSON.parse(localStorage.getItem('formSubmissions') || '[]');
      setFormSubmissions(updatedSubmissions);

      alert('Form submitted successfully!');
    }
  };

  const selectedTemplate = state.templates.find(t => t.id === selectedTemplateId);

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Fill Out a Form</h2>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Select a Template
          </label>
          <select
            value={selectedTemplateId}
            onChange={(e) => setSelectedTemplateId(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="">Select a template</option>
            {state.templates.map(template => (
              <option key={template.id} value={template.id}>{template.name}</option>
            ))}
          </select>
        </div>

        {selectedTemplate && (
          <form onSubmit={handleSubmit}>
            {selectedTemplate.sections.map(section => (
              <div key={section.id} className="mb-8 border-b pb-6">
                <h3 className="text-lg font-medium mb-4">{section.title}</h3>
                <div className="space-y-4">
                  {section.fields.map(field => (
                    <FormField key={field.id} field={field} />
                  ))}
                </div>
              </div>
            ))}

            <div className="mt-8">
              <button
                type="submit"
                className="px-6 py-3 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
              >
                Submit Form
              </button>
            </div>
          </form>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold mb-4">Form Submissions</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Template
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Date Submitted
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {formSubmissions.length > 0 ? (
                formSubmissions.map((submission, index) => {
                  const template = state.templates.find(t => t.id === submission.templateId);
                  return (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{template?.name || 'Unknown Template'}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(submission.timestamp).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <button
                          type="button"
                          className="text-indigo-600 hover:text-indigo-900"
                          onClick={() => alert('Implement view details logic')}
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={3} className="text-center py-8 text-gray-500">
                    No form submissions yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
