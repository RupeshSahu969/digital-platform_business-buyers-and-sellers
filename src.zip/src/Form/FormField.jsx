import React from 'react';
import { useFormBuilder } from '../AuthContext/AuthContext';

export default function FormField({ field }) {
  const { state, updateFormData } = useFormBuilder();
  
  const handleChange = (e) => {
    const { value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;
    updateFormData(field.id, newValue);
  };
  
  const renderField = () => {
    switch (field.type) {
      case 'label':
        const HeadingTag = field.style || 'h2';
        return (
          <HeadingTag className="mt-2 mb-4">
            {field.label}
          </HeadingTag>
        );
      case 'text':
        return (
          <input
            type="text"
            value={state.formData[field.id] || ''}
            onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          />
        );
      case 'number':
        return (
          <input
            type="number"
            value={state.formData[field.id] || ''}
            onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          />
        );
      case 'boolean':
        return (
          <div className="mt-2 flex items-center">
            <input
              id={field.id}
              type="checkbox"
              checked={state.formData[field.id] || false}
              onChange={handleChange}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label htmlFor={field.id} className="ml-2 block text-sm text-gray-900">
              {field.label}
            </label>
          </div>
        );
      case 'enum':
        return (
          <select
            value={state.formData[field.id] || ''}
            onChange={handleChange}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
          >
            <option value="">Select an option</option>
            {field.options?.map((option, index) => (
              <option key={index} value={option}>{option}</option>
            ))}
          </select>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="mb-4">
      {field.type !== 'label' && field.type !== 'boolean' && (
        <label className="block text-sm font-medium text-gray-700">
          {field.label} {field.required && <span className="text-red-500">*</span>}
        </label>
      )}
      {renderField()}
      {state.formErrors[field.id] && (
        <p className="mt-1 text-sm text-red-600">{state.formErrors[field.id]}</p>
      )}
    </div>
  );
}