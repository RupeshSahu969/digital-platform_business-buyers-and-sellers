import React from 'react';

export default function BuilderLayout({ left, center, right }) {
  return (
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-6 p-4">
      <div className="lg:col-span-1">
        {left}
      </div>
      <div className="lg:col-span-2">
        {center}
      </div>
      <div className="lg:col-span-1">
        {right}
      </div>
    </div>
  );
}