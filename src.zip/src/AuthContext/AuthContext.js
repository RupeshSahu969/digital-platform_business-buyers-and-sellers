import React, { createContext, useContext, useReducer, useEffect } from 'react';

const AuthContext = createContext();

const initialState = {
  templates: [],
  currentTemplate: null,
  previewMode: false,
  formData: {},
  formErrors: {}
};

function formBuilderReducer(state, action) {
  switch (action.type) {
    case 'LOAD_TEMPLATES':
      return { ...state, templates: action.payload };
    case 'SET_CURRENT_TEMPLATE':
      return { ...state, currentTemplate: action.payload };
    case 'ADD_TEMPLATE':
      if (state.templates.length >= 5) return state;
      return {
        ...state,
        templates: [...state.templates, action.payload],
        currentTemplate: action.payload
      };
    case 'ADD_SECTION':
      return {
        ...state,
        currentTemplate: {
          ...state.currentTemplate,
          sections: [...state.currentTemplate.sections, action.payload]
        }
      };
    case 'ADD_FIELD':
      return {
        ...state,
        currentTemplate: {
          ...state.currentTemplate,
          sections: state.currentTemplate.sections.map(section => {
            if (section.id === action.sectionId) {
              return {
                ...section,
                fields: [...section.fields, action.payload]
              };
            }
            return section;
          })
        }
      };
    case 'UPDATE_FIELD':
      return {
        ...state,
        currentTemplate: {
          ...state.currentTemplate,
          sections: state.currentTemplate.sections.map(section => {
            if (section.id === action.sectionId) {
              return {
                ...section,
                fields: section.fields.map(field => 
                  field.id === action.fieldId ? { ...field, ...action.updates } : field
                )
              };
            }
            return section;
          })
        }
      };
    case 'DELETE_FIELD':
      return {
        ...state,
        currentTemplate: {
          ...state.currentTemplate,
          sections: state.currentTemplate.sections.map(section => {
            if (section.id === action.sectionId) {
              return {
                ...section,
                fields: section.fields.filter(field => field.id !== action.fieldId)
              };
            }
            return section;
          })
        }
      };
    case 'MOVE_FIELD':
      const { sectionId, fromIndex, toIndex } = action;
      const section = state.currentTemplate.sections.find(s => s.id === sectionId);
      const fields = [...section.fields];
      const [movedField] = fields.splice(fromIndex, 1);
      fields.splice(toIndex, 0, movedField);
      return {
        ...state,
        currentTemplate: {
          ...state.currentTemplate,
          sections: state.currentTemplate.sections.map(s => 
            s.id === sectionId ? { ...s, fields } : s
          )
        }
      };
    case 'TOGGLE_PREVIEW':
      return { ...state, previewMode: !state.previewMode };
    case 'UPDATE_FORM_DATA':
      return {
        ...state,
        formData: {
          ...state.formData,
          [action.fieldId]: action.value
        }
      };
    case 'SET_FORM_ERRORS':
      return { ...state, formErrors: action.payload };
    case 'SUBMIT_FORM':
      return {
        ...state,
        formData: {},
        formErrors: {}
      };
    case 'SAVE_TEMPLATES':
      return {
        ...state,
        templates: state.templates.map(t => 
          t.id === state.currentTemplate.id ? state.currentTemplate : t
        )
      };
    default:
      return state;
  }
}

export function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(formBuilderReducer, initialState);
  
  useEffect(() => {
    const savedTemplates = JSON.parse(localStorage.getItem('formTemplates') || '[]');
    dispatch({ type: 'LOAD_TEMPLATES', payload: savedTemplates });
  }, []);
  
  useEffect(() => {
    localStorage.setItem('formTemplates', JSON.stringify(state.templates));
  }, [state.templates]);
  
  const value = {
    state,
    dispatch,
    createTemplate: (name) => {
      const newTemplate = {
        id: Date.now().toString(),
        name,
        sections: []
      };
      dispatch({ type: 'ADD_TEMPLATE', payload: newTemplate });
    },
    addSection: (templateId) => {
      const newSection = {
        id: `section-${Date.now()}`,
        title: `Section ${state.currentTemplate.sections.length + 1}`,
        fields: []
      };
      dispatch({ type: 'ADD_SECTION', payload: newSection });
    },
    addField: (sectionId, fieldType) => {
      const newField = {
        id: `field-${Date.now()}`,
        type: fieldType,
        label: `New ${fieldType} Field`,
        required: false,
        ...(fieldType === 'label' && { style: 'h2' }),
        ...(fieldType === 'enum' && { options: ['Option 1', 'Option 2'] })
      };
      dispatch({ type: 'ADD_FIELD', sectionId, payload: newField });
    },
    updateField: (sectionId, fieldId, updates) => {
      dispatch({ type: 'UPDATE_FIELD', sectionId, fieldId, updates });
    },
    deleteField: (sectionId, fieldId) => {
      dispatch({ type: 'DELETE_FIELD', sectionId, fieldId });
    },
    moveField: (sectionId, fromIndex, toIndex) => {
      dispatch({ type: 'MOVE_FIELD', sectionId, fromIndex, toIndex });
    },
    togglePreview: () => {
      dispatch({ type: 'TOGGLE_PREVIEW' });
    },
    updateFormData: (fieldId, value) => {
      dispatch({ type: 'UPDATE_FORM_DATA', fieldId, value });
    },
    validateForm: () => {
      const errors = {};
      
      if (!state.currentTemplate) return errors;
      
      state.currentTemplate.sections.forEach(section => {
        section.fields.forEach(field => {
          if (field.required && !state.formData[field.id]) {
            errors[field.id] = 'This field is required';
          }
          
          if (field.type === 'number' && state.formData[field.id] && isNaN(Number(state.formData[field.id]))) {
            errors[field.id] = 'Please enter a valid number';
          }
        });
      });
      
      dispatch({ type: 'SET_FORM_ERRORS', payload: errors });
      return Object.keys(errors).length === 0;
    },
    submitForm: () => {
      const formSubmissions = JSON.parse(localStorage.getItem('formSubmissions') || '[]');
      const newSubmission = {
        templateId: state.currentTemplate.id,
        data: state.formData,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem('formSubmissions', JSON.stringify([...formSubmissions, newSubmission]));
      dispatch({ type: 'SUBMIT_FORM' });
    },
    saveTemplates: () => {
      dispatch({ type: 'SAVE_TEMPLATES' });
    }
  };
  
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useFormBuilder() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useFormBuilder must be used within a AuthProvider');
  }
  return context;
}