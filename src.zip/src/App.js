// src/App.js
import React, { useState } from "react";
import BuilderPage from "./Pages/BuilderPage";
import FormPage from "./Pages/FormPage";
import Footer from "./Components/Footer";
import Navbar from "./Components/Navbar";

function App() {
  const [activeTab, setActiveTab] = useState("builder");

  const tabClass = (tab) =>
    `w-full sm:w-auto text-center px-4 py-2 rounded-t-lg font-semibold transition-all duration-200 
     ${
       activeTab === tab
         ? "text-white bg-indigo-600"
         : "text-gray-600 bg-gray-200 hover:bg-gray-300"
     }`;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <main className="flex-grow py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Responsive Tabs */}
          {/* Responsive Tabs */}
          <div className="flex flex-wrap gap-2 border-b border-gray-300 mb-6">
            <button
              className={tabClass("builder")}
              onClick={() => setActiveTab("builder")}
            >
              Template Builder
            </button>
            <button
              className={tabClass("forms")}
              onClick={() => setActiveTab("forms")}
            >
              Forms
            </button>
          </div>

          {/* Render Page */}
          <div className="bg-white shadow-sm rounded-lg p-4 sm:p-6">
            {activeTab === "builder" ? <BuilderPage /> : <FormPage />}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;
