import React from 'react';
import FormPage from '../Form/FormPage';

export default function FormPageWrapper() {
    return <FormPage />;
}