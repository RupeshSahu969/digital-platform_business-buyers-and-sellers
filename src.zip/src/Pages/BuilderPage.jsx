import React from 'react';
import TemplateSelector from '../Builder/TemplateSelector';
import BuilderPage from '../Builder/BuilderPage';

export default function BuilderPageWrapper() {
  return (
    <>
      <TemplateSelector />
      {/* <BuilderPage /> */}
    </>
  );
}