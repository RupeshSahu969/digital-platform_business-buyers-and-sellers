import React from 'react';
import { useFormBuilder } from '../AuthContext/AuthContext';

export default function TemplateSelector() {
  const { state, dispatch } = useFormBuilder();

  const handleCreateTemplate = () => {
    const name = prompt('Enter template name:');
    if (name) {
      dispatch({
        type: 'ADD_TEMPLATE',
        payload: {
          id: Date.now().toString(),
          name,
          sections: [],
        },
      });
    }
  };

  const maxTemplatesReached = state.templates.length >= 5;

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Templates</h2>
        <button
          onClick={handleCreateTemplate}
          disabled={maxTemplatesReached}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            maxTemplatesReached
              ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-700 text-white'
          }`}
        >
          New Template
        </button>
      </div>

      {state.templates.length === 0 ? (
        <p className="text-gray-500 italic">
          No templates created yet. Click "New Template" to get started.
        </p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {state.templates.map((template) => {
            const isActive = state.currentTemplate?.id === template.id;
            const totalFields = template.sections.reduce(
              (acc, sec) => acc + sec.fields.length,
              0
            );

            return (
              <div
                key={template.id}
                onClick={() =>
                  dispatch({ type: 'SET_CURRENT_TEMPLATE', payload: template })
                }
                role="button"
                tabIndex={0}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    dispatch({ type: 'SET_CURRENT_TEMPLATE', payload: template });
                  }
                }}
                className={`border rounded-lg p-4 cursor-pointer transition-all focus:outline-none focus:ring-2 ${
                  isActive
                    ? 'border-indigo-500 bg-indigo-50 ring-indigo-300'
                    : 'border-gray-200 hover:border-indigo-300'
                }`}
              >
                <h3 className="font-medium text-lg text-gray-900">{template.name}</h3>
                <p className="text-sm text-gray-500 mt-1">
                  {template.sections.length} section{template.sections.length !== 1 ? 's' : ''},{' '}
                  {totalFields} field{totalFields !== 1 ? 's' : ''}
                </p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
