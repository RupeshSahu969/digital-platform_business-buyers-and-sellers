import React from 'react';
import { useFormBuilder } from '../AuthContext/AuthContext';

export default function PreviewField({ field }) {
  const { state, updateFormData } = useFormBuilder();

  const handleChange = (e) => {
    const { value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;
    updateFormData(field.id, newValue);
  };

  const renderField = () => {
    switch (field.type) {
      case 'label':
        const HeadingTag = field.style || 'h2';
        return <HeadingTag className="mt-2 mb-4 font-semibold">{field.label}</HeadingTag>;

      case 'text':
      case 'number':
        return (
          <input
            type={field.type}
            id={field.id}
            value={state.formData[field.id] || ''}
            onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          />
        );

      case 'boolean':
        return (
          <div className="mt-2 flex items-center">
            <input
              id={field.id}
              type="checkbox"
              checked={state.formData[field.id] || false}
              onChange={handleChange}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label htmlFor={field.id} className="ml-2 text-sm text-gray-900">
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </label>
          </div>
        );

      case 'enum':
        return (
          <select
            id={field.id}
            value={state.formData[field.id] || ''}
            onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white text-gray-900 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">Select an option</option>
            {field.options?.map((option, index) => (
              <option key={index} value={option}>
                {option}
              </option>
            ))}
          </select>
        );

      default:
        return null;
    }
  };

  return (
    <div className="mb-5">
      {field.type !== 'label' && field.type !== 'boolean' && (
        <label htmlFor={field.id} className="block text-sm font-medium text-gray-700 mb-1">
          {field.label}
          {field.required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      {renderField()}
      {state.formErrors[field.id] && (
        <p className="mt-1 text-sm text-red-600">{state.formErrors[field.id]}</p>
      )}
    </div>
  );
}
