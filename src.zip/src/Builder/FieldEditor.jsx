import React from 'react';
import { useFormBuilder } from '../AuthContext/AuthContext';

export default function FieldEditor({ field, sectionId }) {
  const { updateField } = useFormBuilder();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;
    updateField(sectionId, field.id, { [name]: newValue });
  };

  const handleOptionsChange = (index, value) => {
    const newOptions = [...field.options];
    newOptions[index] = value;
    updateField(sectionId, field.id, { options: newOptions });
  };

  const addOption = () => {
    updateField(sectionId, field.id, { options: [...field.options, 'New option'] });
  };

  const removeOption = (index) => {
    const newOptions = field.options.filter((_, i) => i !== index);
    updateField(sectionId, field.id, { options: newOptions });
  };

  return (
    <div className="flex-1">
      {/* Label */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">Label</label>
        <input
          type="text"
          name="label"
          value={field.label}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      {/* Label-style dropdown for "label" type */}
      {field.type === 'label' && (
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">Heading Level</label>
          <select
            name="style"
            value={field.style}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="h1">Heading 1 (H1)</option>
            <option value="h2">Heading 2 (H2)</option>
            <option value="h3">Heading 3 (H3)</option>
          </select>
        </div>
      )}

      {/* Enum Options */}
      {field.type === 'enum' && (
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">Options</label>
          <div className="space-y-2">
            {field.options.map((option, index) => (
              <div key={index} className="flex items-center gap-2">
                <input
                  type="text"
                  value={option}
                  onChange={(e) => handleOptionsChange(index, e.target.value)}
                  className="flex-1 px-3 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button
                  onClick={() => removeOption(index)}
                  className="text-red-500 hover:text-red-700"
                  aria-label="Remove option"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path
                      fillRule="evenodd"
                      d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>
              </div>
            ))}
            <button
              onClick={addOption}
              className="mt-2 inline-flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-md text-sm hover:bg-gray-200 transition"
            >
              + Add Option
            </button>
          </div>
        </div>
      )}

      {/* Required toggle */}
      <div className="flex items-center mt-4">
        <input
          id={`required-${field.id}`}
          name="required"
          type="checkbox"
          checked={field.required}
          onChange={handleChange}
          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
        />
        <label htmlFor={`required-${field.id}`} className="ml-2 block text-sm text-gray-900">
          Required
        </label>
      </div>
    </div>
  );
}
