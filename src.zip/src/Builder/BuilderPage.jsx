import React from 'react';
import SectionEditor from './SectionEditor';
import PreviewField from './PreviewField';
import { useFormBuilder } from '../AuthContext/AuthContext';
import { FiFile, FiPlusSquare, FiCheckCircle, FiChevronDown, FiCheck } from 'react-icons/fi'; // import icons as needed

export default function BuilderPage() {
  const { state, dispatch, addSection, addField, togglePreview } = useFormBuilder();

  if (!state.currentTemplate) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center py-12">
          <FiFile className="mx-auto text-gray-400" size={64} />
          <h2 className="mt-4 text-xl font-medium text-gray-900">No Template Selected</h2>
          <p className="mt-2 text-gray-500">Please select or create a template to start building your form.</p>
        </div>
      </div>
    );
  }

  const handleAddField = (type) => {
    if (state.currentTemplate.sections.length > 0) {
      addField(state.currentTemplate.sections[0].id, type);
    } else {
      const newSection = {
        id: `section-${Date.now()}`,
        title: `Section 1`,
        fields: []
      };
      dispatch({ type: 'ADD_SECTION', payload: newSection });
      setTimeout(() => {
        addField(newSection.id, type);
      }, 10);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-800">
          Building: {state.currentTemplate.name}
        </h2>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={togglePreview}
            className="px-4 py-2 text-sm sm:text-base bg-indigo-600 text-white hover:text-white rounded-md hover:bg-indigo-700 transition"
          >
            {state.previewMode ? 'Edit Template' : 'Preview Form'}
          </button>
          <button
            onClick={() => dispatch({ type: 'SAVE_TEMPLATES' })}
            className="px-4 py-2 text-sm sm:text-base bg-green-600 text-white  hover:text-white rounded-md hover:bg-green-700 transition"
          >
            Save Template
          </button>
        </div>
      </div>

      {/* Main Body */}
      {state.previewMode ? (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg sm:text-xl font-semibold mb-4">Form Preview</h3>
          {state.currentTemplate.sections.map(section => (
            <div key={section.id} className="mb-8 pb-6">
              <h4 className="text-md sm:text-lg font-medium mb-4 pb-2 border-b">{section.title}</h4>
              <div className="space-y-4">
                {section.fields.map(field => (
                  <PreviewField key={field.id} field={field} />
                ))}
              </div>
            </div>
          ))}
          {state.currentTemplate.sections.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <p>No sections or fields added yet.</p>
            </div>
          )}
        </div>
      ) : (
        <>
          <div className="mb-6">
            <button
              onClick={() => addSection(state.currentTemplate.id)}
              className="px-4 py-2 bg-indigo-600 text-white hover:text-white rounded-md hover:bg-indigo-700 transition"
            >
              + Add Section
            </button>
          </div>

          {/* Section Editors */}
          {state.currentTemplate.sections.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
              <FiPlusSquare className="mx-auto text-gray-400" size={48} />
              <h3 className="mt-4 text-lg font-medium text-gray-900">No sections added</h3>
              <p className="mt-2 text-gray-500">Get started by adding your first section.</p>
              <button
                onClick={() => addSection(state.currentTemplate.id)}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition"
              >
                Add Section
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {state.currentTemplate.sections.map(section => (
                <SectionEditor key={section.id} section={section} />
              ))}
            </div>
          )}

          {/* Field Type Buttons */}
          <div className="mt-10 bg-gray-50 p-5 rounded-lg border">
            <h3 className="font-medium text-lg mb-4">Add Field Type</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {['label', 'text', 'number', 'boolean', 'enum'].map(type => (
                <button
                  key={type}
                  onClick={() => handleAddField(type)}
                  className="p-4 bg-white border rounded-lg shadow-sm hover:bg-indigo-50 transition"
                >
                  <div className="flex flex-col items-center">
                    <div className="mb-2 bg-indigo-100 rounded-full p-2 w-12 h-12 flex items-center justify-center">
                      {type === 'label' && <span className="text-lg font-bold">T</span>}
                      {type === 'text' && <span className="text-lg">Aa</span>}
                      {type === 'number' && <span className="text-lg">123</span>}
                      {type === 'boolean' && <FiCheckCircle className="text-indigo-600" size={20} />}
                      {type === 'enum' && <FiChevronDown className="text-indigo-600" size={20} />}
                    </div>
                    <span className="capitalize text-sm sm:text-base">{type}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
