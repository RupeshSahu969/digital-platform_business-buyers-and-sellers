import React, { useState } from 'react';
import FieldEditor from './FieldEditor';
import { useFormBuilder } from '../AuthContext/AuthContext';
import { FiTrash2, FiMenu } from 'react-icons/fi';

export default function SectionEditor({ section }) {
    const { addField, deleteField, moveField } = useFormBuilder();
    const [draggingIndex, setDraggingIndex] = useState(null);

    const handleDragStart = (e, index) => {
        e.dataTransfer.setData('text/plain', index);
        setDraggingIndex(index);
    };

    const handleDragOver = (e) => {
        e.preventDefault(); 
    };

    const handleDrop = (e, targetIndex) => {
        e.preventDefault();
        const fromIndex = parseInt(e.dataTransfer.getData('text/plain'), 10);
        if (fromIndex !== targetIndex) {
            moveField(section.id, fromIndex, targetIndex);
        }
        setDraggingIndex(null);
    };

    return (
        <div className="mb-8 border rounded-lg p-4 bg-white shadow-sm">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">{section.title}</h3>
                <button
                    onClick={() => addField(section.id, 'text')}
                    className="px-3 py-1 bg-green-500 text-white rounded-md text-sm hover:bg-green-600 transition-colors"
                >
                    Add Field
                </button>
            </div>

            <div className="space-y-3">
                {section.fields.map((field, index) => (
                    <div
                        key={field.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, index)}
                        onDragOver={handleDragOver}
                        onDrop={(e) => handleDrop(e, index)}
                        className={`border rounded-lg p-3 flex items-start group transition-colors ${draggingIndex === index ? 'bg-blue-50 border-blue-300' : 'bg-white'
                            }`}
                    >
                        <div
                            className="mr-2 cursor-move text-gray-400 hover:text-gray-600 transition-colors"
                            title="Drag to reorder"
                        >
                            <FiMenu size={20} />
                        </div>
                        <FieldEditor field={field} sectionId={section.id} />
                        <button
                            onClick={() => deleteField(section.id, field.id)}
                            title="Delete field"
                            className="ml-auto text-red-400 hover:text-red-500 bg-gray-50 botder-none"
                        >
                            <FiTrash2 size={20} className='border-none' />
                        </button>
                    </div>
                ))}

                {section.fields.length === 0 && (
                    <div className="text-center py-6 text-gray-500 border-2 border-dashed rounded-lg">
                        <p>No fields in this section</p>
                        <button
                            onClick={() => addField(section.id, 'text')}
                            className="mt-2 px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md text-sm hover:bg-indigo-200 transition-colors"
                        >
                            Add First Field
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
